Settings
********

Some of pikepdf's global parameters can be tuned.

.. autofunction:: pikepdf.settings.get_decimal_precision

.. autofunction:: pikepdf.settings.set_decimal_precision

.. autofunction:: pikepdf.settings.set_flate_compression_level